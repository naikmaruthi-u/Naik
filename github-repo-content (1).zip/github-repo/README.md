# 👋 Hi, I'm Maruthi Naik

### Senior Azure Cloud Engineer | Terraform Certified | AZ-104 | ITIL Foundation

> 13+ years of enterprise IT experience across Azure IaaS, Windows infrastructure, DevOps pipelines, patch management, and production platform support.

---

## 🏅 Certifications

![Terraform](https://img.shields.io/badge/HashiCorp_Terraform-Associate-7B42BC?style=for-the-badge&logo=terraform&logoColor=white)
![AZ-104](https://img.shields.io/badge/Microsoft_Azure-AZ--104-0078D4?style=for-the-badge&logo=microsoftazure&logoColor=white)
![AZ-305](https://img.shields.io/badge/Microsoft_Azure-AZ--305_In_Progress-orange?style=for-the-badge&logo=microsoftazure&logoColor=white)
![ITIL](https://img.shields.io/badge/ITIL_Foundation-Certified-6B3FA0?style=for-the-badge)

---

## 🛠️ Tech Stack

| Category | Skills |
|---|---|
| ☁️ **Azure** | IaaS, Virtual Machines, Storage, Networking, Azure Monitor, Backup, Site Recovery, Entra ID, RBAC |
| 🏗️ **IaC** | Terraform (Certified), ARM Templates, Azure Bicep |
| ⚙️ **DevOps** | Azure DevOps, CI/CD Pipelines, GitHub Actions, PowerShell |
| 🔒 **Identity** | Azure Active Directory, Entra ID, RBAC, MFA, Conditional Access |
| 🖥️ **Windows** | Server 2016/2019/2022, Patching, Group Policy, DNS, DHCP |
| 📊 **Monitoring** | Azure Monitor, Log Analytics, Alerts, Dashboards |
| 🎫 **ITSM** | ServiceNow, Incident Management, Change Management, SLA |

---

## 📁 Repository Contents

| Folder | What's inside |
|---|---|
| [`/terraform/azure-vm`](./terraform/azure-vm/) | Terraform module to deploy Azure Windows VMs with NSG, NIC, and managed disks |
| [`/terraform/azure-monitor`](./terraform/azure-monitor/) | Terraform to deploy Azure Monitor alerts and Log Analytics workspace |
| [`/powershell`](./powershell/) | PowerShell scripts for Azure health checks, patch reporting, and backup validation |
| [`/arm-templates`](./arm-templates/) | ARM templates for quick Azure resource deployments |
| [`/.github/workflows`](./.github/workflows/) | GitHub Actions pipelines: Terraform validate, plan on PR |

---

## 🔹 Project Highlights

### ARUP — Azure Platform Support & DevOps Enablement
- Supported Azure VM, storage, and networking infrastructure across Dev/Test/Prod
- Managed RBAC and Entra ID access with customer coordination
- Supported Azure DevOps pipelines ensuring smooth CI/CD delivery
- Resolved firewall and connectivity issues across environments

### FRP — Patch Management & Infrastructure Operations
- Managed end-to-end patching strategy for UAT and Production servers
- Ensured minimal downtime using planned maintenance windows
- Monitored Azure Backup and Recovery; resolved job failures proactively

### KRG / Shared Services — Monitoring & Incident Management
- Monitored multi-customer environments via Azure Monitor and custom dashboards
- Handled P1/P2 on-call incidents within SLA using ServiceNow

---

## 📊 GitHub Stats

![Maruthi's GitHub Stats](https://github-readme-stats.vercel.app/api?username=naikmaruthi-u&show_icons=true&theme=tokyonight&hide_border=true)
![Top Languages](https://github-readme-stats.vercel.app/api/top-langs/?username=naikmaruthi-u&layout=compact&theme=tokyonight&hide_border=true)

---

## 📫 Connect with me

[![LinkedIn](https://img.shields.io/badge/LinkedIn-Maruthi_Naik-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://linkedin.com/in/maruthi-naik)
[![Email](https://img.shields.io/badge/Email-naikmaruthi@gmail.com-D14836?style=for-the-badge&logo=gmail&logoColor=white)](mailto:naikmaruthi@gmail.com)
[![Location](https://img.shields.io/badge/Location-Bangalore,_India-FF5733?style=for-the-badge&logo=googlemaps&logoColor=white)](https://maps.google.com/?q=Bangalore,India)

---

> 💡 *Currently pursuing AZ-305 (Azure Solutions Architect Expert) — targeting Senior Cloud Architect roles at ₹29–35 LPA*
