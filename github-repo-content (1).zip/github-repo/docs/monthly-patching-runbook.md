# Monthly Patching Runbook — Azure Windows Servers

**Author:** Maruthi Naik — Senior Azure Cloud Engineer  
**Last Updated:** June 2026  
**Version:** 2.1  

---

## Overview

This runbook defines the end-to-end monthly patching procedure for Azure Windows Server environments across UAT and Production, ensuring compliance, minimal downtime, and full rollback capability.

---

## Patching Schedule

| Environment | Patching Window | Day |
|---|---|---|
| UAT | 20:00 – 00:00 IST | 2nd Tuesday of month |
| Production | 22:00 – 03:00 IST | 3rd Tuesday of month (Patch Tuesday +1 week) |

---

## Pre-Patching Checklist (T-48 hours)

### 1. Communication
- [ ] Send maintenance window notification to stakeholders (email/Teams)
- [ ] Log Change Request in ServiceNow — get CAB approval
- [ ] Notify on-call team of patching window

### 2. Environment Validation
- [ ] Confirm Azure Monitor alerts are active and routed correctly
- [ ] Verify Azure Backup job ran successfully within last 24 hours
- [ ] Check VM health status in Azure Portal — all VMs in "Running" state
- [ ] Validate disk space > 10 GB free on all VMs
- [ ] Run `azure-health-check.ps1` and review output

```powershell
# Run health check before patching
.\powershell\azure-health-check.ps1 -SubscriptionId "<your-sub-id>" -ResourceGroupName "rg-prod"
```

### 3. Snapshot / Backup Confirmation
- [ ] Confirm Azure Backup completed successfully for all in-scope VMs
- [ ] Note backup recovery point timestamps for rollback reference

---

## Patching Execution

### Step 1 — Start maintenance mode
```powershell
# Suppress Azure Monitor alerts during maintenance window
$actionGroupId = "<your-action-group-id>"
New-AzActionGroup -SuppressionStartTime (Get-Date) -SuppressionEndTime (Get-Date).AddHours(4)
```

### Step 2 — Apply patches via Azure Update Manager
1. Navigate to **Azure Update Manager** in the Azure Portal
2. Select the VM(s) in scope
3. Click **One-time update** → select patch classification:
   - ✅ Critical updates
   - ✅ Security updates
   - ✅ Update rollups
4. Set reboot option: **Always reboot if required**
5. Confirm and initiate

### Step 3 — Monitor patching progress
- Monitor in **Azure Update Manager > History** tab
- Watch for status: `InProgress` → `Succeeded` / `Failed`

### Step 4 — Post-patch health checks
Run within 30 minutes of patching completion:

```powershell
# Post-patch validation
.\powershell\azure-health-check.ps1 -SubscriptionId "<sub-id>" -ResourceGroupName "rg-prod"

# Verify services are running
Get-Service -ComputerName <vm-name> | Where-Object Status -eq "Stopped" | Format-Table -AutoSize

# Check Windows Update history
Get-HotFix | Sort-Object InstalledOn -Descending | Select-Object -First 10
```

- [ ] All VMs in "Running" state post-reboot
- [ ] CPU and memory within normal range
- [ ] Application/service availability confirmed with app teams
- [ ] No critical alerts triggered post-patching

---

## Rollback Procedure

If post-patch health check fails:

1. **Identify** — determine which VM(s) are affected
2. **Restore from backup** — use Azure Backup restore to latest recovery point
3. **Notify** — alert stakeholders and CAB of rollback
4. **Document** — log incident in ServiceNow with RCA

```powershell
# Initiate Azure Backup restore (example)
$vault = Get-AzRecoveryServicesVault -Name "vault-prod"
Set-AzRecoveryServicesVaultContext -Vault $vault
$container  = Get-AzRecoveryServicesBackupContainer -ContainerType AzureVM -FriendlyName "<vm-name>"
$backupItem = Get-AzRecoveryServicesBackupItem -Container $container -WorkloadType AzureVM
$rp         = Get-AzRecoveryServicesBackupRecoveryPoint -Item $backupItem | Select-Object -First 1
Restore-AzRecoveryServicesBackupItem -RecoveryPoint $rp -StorageAccountName "<storage>" -StorageAccountResourceGroupName "<rg>"
```

---

## Post-Patching Closure

- [ ] Update ServiceNow change ticket to **Closed — Successful**
- [ ] Update patch compliance report
- [ ] Send completion notification to stakeholders
- [ ] Run `patch-report.ps1` and attach to change ticket

```powershell
.\powershell\patch-report.ps1 -SubscriptionId "<sub-id>" -ResourceGroupName "rg-prod"
```

---

## Contacts

| Role | Contact |
|---|---|
| Cloud Engineer | Maruthi Naik — naikmaruthi@gmail.com |
| On-call escalation | Version 1 On-Call Rota |
| CAB approval | ServiceNow — Change Management queue |
