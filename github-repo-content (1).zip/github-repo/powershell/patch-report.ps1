<#
.SYNOPSIS
    Azure VM Patch Compliance Report
.DESCRIPTION
    Generates a patch compliance report for all Azure VMs using
    Azure Update Manager. Reports missing patches, last patch time,
    and compliance status per VM. Designed for monthly patching cycles.
.AUTHOR
    Maruthi Naik | Senior Azure Cloud Engineer
.NOTES
    Run: .\patch-report.ps1 -SubscriptionId "your-sub-id" -ResourceGroupName "rg-prod"
#>

param(
    [Parameter(Mandatory = $true)]  [string]$SubscriptionId,
    [Parameter(Mandatory = $false)] [string]$ResourceGroupName = "*",
    [Parameter(Mandatory = $false)] [string]$OutputPath = ".\PatchReport_$(Get-Date -Format 'yyyyMMdd').csv",
    [Parameter(Mandatory = $false)] [switch]$SendEmail,
    [Parameter(Mandatory = $false)] [string]$AlertEmail
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Continue"

function Write-Log {
    param([string]$Level, [string]$Message)
    $timestamp = Get-Date -Format "HH:mm:ss"
    $color = switch ($Level) {
        "INFO" { "Cyan" }; "OK" { "Green" }; "WARN" { "Yellow" }; "CRIT" { "Red" }
    }
    Write-Host "[$timestamp][$Level] $Message" -ForegroundColor $color
}

Write-Log "INFO" "=== Azure Patch Compliance Report — $(Get-Date -Format 'dd MMM yyyy') ==="
Connect-AzAccount -Subscription $SubscriptionId | Out-Null
Set-AzContext -SubscriptionId $SubscriptionId | Out-Null
Write-Log "OK" "Connected to subscription: $SubscriptionId"

$vms = if ($ResourceGroupName -eq "*") { Get-AzVM } else { Get-AzVM -ResourceGroupName $ResourceGroupName }
Write-Log "INFO" "Scanning $($vms.Count) VMs for patch compliance..."

$patchReport = @()

foreach ($vm in $vms) {
    Write-Log "INFO" "Checking patches: $($vm.Name)"

    $patchResult = [PSCustomObject]@{
        VMName              = $vm.Name
        ResourceGroup       = $vm.ResourceGroupName
        Location            = $vm.Location
        OSType              = $vm.StorageProfile.OsDisk.OsType
        CriticalMissing     = 0
        SecurityMissing     = 0
        OtherMissing        = 0
        TotalMissing        = 0
        LastPatchTime       = "N/A"
        PatchStatus         = "Unknown"
        PatchMode           = "Unknown"
        ComplianceState     = "Unknown"
        RebootRequired      = "Unknown"
        CheckTime           = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
    }

    try {
        # Get patch assessment
        $assessment = Invoke-AzRestMethod `
            -Path "/subscriptions/$SubscriptionId/resourceGroups/$($vm.ResourceGroupName)/providers/Microsoft.Compute/virtualMachines/$($vm.Name)/assessPatches?api-version=2022-11-01" `
            -Method POST `
            -ErrorAction SilentlyContinue

        if ($assessment.StatusCode -in 200, 202) {
            $data = ($assessment.Content | ConvertFrom-Json)
            $patchResult.CriticalMissing = ($data.availablePatchSummary.criticalAndSecurityPatchCount) ?? 0
            $patchResult.OtherMissing    = ($data.availablePatchSummary.otherPatchCount) ?? 0
            $patchResult.TotalMissing    = $patchResult.CriticalMissing + $patchResult.OtherMissing
            $patchResult.RebootRequired  = $data.availablePatchSummary.rebootPending ?? "Unknown"
            $patchResult.LastPatchTime   = $data.lastPatchInstallationSummary.lastModifiedTime ?? "Never"

            if ($patchResult.CriticalMissing -gt 0) {
                $patchResult.ComplianceState = "NON-COMPLIANT"
                Write-Log "CRIT" "$($vm.Name): $($patchResult.CriticalMissing) CRITICAL patches missing!"
            } elseif ($patchResult.TotalMissing -gt 0) {
                $patchResult.ComplianceState = "PARTIAL"
                Write-Log "WARN" "$($vm.Name): $($patchResult.TotalMissing) patches pending"
            } else {
                $patchResult.ComplianceState = "COMPLIANT"
                Write-Log "OK"   "$($vm.Name): Fully patched"
            }
        }
    } catch {
        $patchResult.ComplianceState = "Assessment Failed"
        Write-Log "WARN" "Could not assess $($vm.Name): $_"
    }

    $patchReport += $patchResult
}

# ── Summary ───────────────────────────────────────────────────
$compliant    = ($patchReport | Where-Object ComplianceState -eq "COMPLIANT").Count
$nonCompliant = ($patchReport | Where-Object ComplianceState -eq "NON-COMPLIANT").Count
$partial      = ($patchReport | Where-Object ComplianceState -eq "PARTIAL").Count

Write-Log "INFO"  "=== PATCH COMPLIANCE SUMMARY ==="
Write-Log "OK"    "Compliant     : $compliant VMs"
Write-Log "WARN"  "Partial       : $partial VMs"
Write-Log "CRIT"  "Non-Compliant : $nonCompliant VMs"

$patchReport | Export-Csv -Path $OutputPath -NoTypeInformation -Encoding UTF8
Write-Log "OK" "Report exported: $OutputPath"
