<#
.SYNOPSIS
    Azure VM Health Check Script
.DESCRIPTION
    Performs a comprehensive health check across Azure VMs in a subscription.
    Checks VM power state, CPU/memory metrics, disk usage, backup status,
    and NSG compliance. Outputs a colour-coded summary report.
.AUTHOR
    Maruthi Naik | Senior Azure Cloud Engineer
.NOTES
    Requires: Az PowerShell module (Install-Module Az)
    Run: .\azure-health-check.ps1 -SubscriptionId "your-sub-id"
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$SubscriptionId,

    [Parameter(Mandatory = $false)]
    [string]$ResourceGroupName = "*",   # "*" checks all resource groups

    [Parameter(Mandatory = $false)]
    [string]$OutputPath = ".\HealthReport_$(Get-Date -Format 'yyyyMMdd_HHmm').csv"
)

# ── Initialise ────────────────────────────────────────────────
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Write-Header {
    param([string]$Text)
    Write-Host "`n$('=' * 60)" -ForegroundColor Cyan
    Write-Host "  $Text" -ForegroundColor Cyan
    Write-Host "$('=' * 60)" -ForegroundColor Cyan
}

function Write-Status {
    param([string]$Status, [string]$Message)
    switch ($Status) {
        "OK"   { Write-Host "  [OK]   $Message" -ForegroundColor Green }
        "WARN" { Write-Host "  [WARN] $Message" -ForegroundColor Yellow }
        "CRIT" { Write-Host "  [CRIT] $Message" -ForegroundColor Red }
        "INFO" { Write-Host "  [INFO] $Message" -ForegroundColor White }
    }
}

# ── Connect to Azure ──────────────────────────────────────────
Write-Header "Azure VM Health Check — $(Get-Date -Format 'dd MMM yyyy HH:mm')"
Write-Status "INFO" "Connecting to Azure subscription: $SubscriptionId"

try {
    Connect-AzAccount -Subscription $SubscriptionId | Out-Null
    Set-AzContext -SubscriptionId $SubscriptionId | Out-Null
    Write-Status "OK" "Connected successfully"
} catch {
    Write-Status "CRIT" "Failed to connect: $_"
    exit 1
}

# ── Get VMs ───────────────────────────────────────────────────
$vms = if ($ResourceGroupName -eq "*") {
    Get-AzVM -Status
} else {
    Get-AzVM -ResourceGroupName $ResourceGroupName -Status
}

Write-Status "INFO" "Found $($vms.Count) VM(s) to check"

$report = @()

foreach ($vm in $vms) {
    Write-Header "Checking: $($vm.Name) [$($vm.ResourceGroupName)]"

    $result = [PSCustomObject]@{
        VMName            = $vm.Name
        ResourceGroup     = $vm.ResourceGroupName
        Location          = $vm.Location
        PowerState        = $vm.PowerState
        VMSize            = $vm.HardwareProfile.VmSize
        OSType            = $vm.StorageProfile.OsDisk.OsType
        CPUStatus         = "Unknown"
        MemoryStatus      = "Unknown"
        BackupStatus      = "Unknown"
        NSGAttached       = "Unknown"
        OverallHealth     = "OK"
        CheckTime         = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
        Notes             = ""
    }

    # ── Power State ──────────────────────────────────────────
    if ($vm.PowerState -eq "VM running") {
        Write-Status "OK" "Power state: Running"
    } else {
        Write-Status "WARN" "Power state: $($vm.PowerState)"
        $result.OverallHealth = "WARN"
        $result.Notes += "VM not running; "
    }

    # ── CPU Metrics (last 5 minutes) ─────────────────────────
    try {
        $cpuMetric = Get-AzMetric `
            -ResourceId $vm.Id `
            -MetricName "Percentage CPU" `
            -StartTime (Get-Date).AddMinutes(-5) `
            -EndTime (Get-Date) `
            -TimeGrain "00:05:00" `
            -AggregationType Average `
            -ErrorAction SilentlyContinue

        $cpuValue = [math]::Round(($cpuMetric.Data | Select-Object -Last 1).Average, 2)

        if ($cpuValue -gt 85) {
            Write-Status "CRIT" "CPU: $cpuValue% (CRITICAL > 85%)"
            $result.CPUStatus = "CRIT ($cpuValue%)"
            $result.OverallHealth = "CRIT"
            $result.Notes += "High CPU; "
        } elseif ($cpuValue -gt 70) {
            Write-Status "WARN" "CPU: $cpuValue% (WARNING > 70%)"
            $result.CPUStatus = "WARN ($cpuValue%)"
            if ($result.OverallHealth -ne "CRIT") { $result.OverallHealth = "WARN" }
        } else {
            Write-Status "OK" "CPU: $cpuValue%"
            $result.CPUStatus = "OK ($cpuValue%)"
        }
    } catch {
        Write-Status "WARN" "Could not retrieve CPU metrics"
        $result.CPUStatus = "Unavailable"
    }

    # ── NSG Check ────────────────────────────────────────────
    try {
        $nic = Get-AzNetworkInterface -ResourceId ($vm.NetworkProfile.NetworkInterfaces[0].Id) -ErrorAction SilentlyContinue
        $hasNsg = ($null -ne $nic.NetworkSecurityGroup) -or ($null -ne $nic.IpConfigurations[0].Subnet.NetworkSecurityGroup)

        if ($hasNsg) {
            Write-Status "OK" "NSG: Attached"
            $result.NSGAttached = "Yes"
        } else {
            Write-Status "WARN" "NSG: Not attached — security risk!"
            $result.NSGAttached = "No"
            if ($result.OverallHealth -ne "CRIT") { $result.OverallHealth = "WARN" }
            $result.Notes += "No NSG; "
        }
    } catch {
        $result.NSGAttached = "Check failed"
    }

    # ── Backup Status ─────────────────────────────────────────
    try {
        $vaults = Get-AzRecoveryServicesVault -ResourceGroupName $vm.ResourceGroupName -ErrorAction SilentlyContinue
        $backupFound = $false

        foreach ($vault in $vaults) {
            Set-AzRecoveryServicesVaultContext -Vault $vault
            $container = Get-AzRecoveryServicesBackupContainer `
                -ContainerType "AzureVM" `
                -Status "Registered" `
                -FriendlyName $vm.Name `
                -ErrorAction SilentlyContinue

            if ($container) {
                $backupFound = $true
                $backupItem = Get-AzRecoveryServicesBackupItem `
                    -Container $container `
                    -WorkloadType "AzureVM" `
                    -ErrorAction SilentlyContinue

                if ($backupItem.LastBackupStatus -eq "Completed") {
                    Write-Status "OK" "Backup: Last backup completed at $($backupItem.LastBackupTime)"
                    $result.BackupStatus = "OK - $($backupItem.LastBackupTime)"
                } else {
                    Write-Status "WARN" "Backup status: $($backupItem.LastBackupStatus)"
                    $result.BackupStatus = "WARN - $($backupItem.LastBackupStatus)"
                    if ($result.OverallHealth -ne "CRIT") { $result.OverallHealth = "WARN" }
                }
                break
            }
        }

        if (-not $backupFound) {
            Write-Status "WARN" "Backup: No backup configured!"
            $result.BackupStatus = "Not configured"
            if ($result.OverallHealth -ne "CRIT") { $result.OverallHealth = "WARN" }
            $result.Notes += "No backup; "
        }
    } catch {
        $result.BackupStatus = "Check failed"
    }

    # ── Overall Summary ───────────────────────────────────────
    switch ($result.OverallHealth) {
        "OK"   { Write-Status "OK"   "Overall: HEALTHY" }
        "WARN" { Write-Status "WARN" "Overall: NEEDS ATTENTION" }
        "CRIT" { Write-Status "CRIT" "Overall: CRITICAL — immediate action required" }
    }

    $report += $result
}

# ── Export Report ─────────────────────────────────────────────
Write-Header "Health Check Summary"

$healthyCount = ($report | Where-Object OverallHealth -eq "OK").Count
$warnCount    = ($report | Where-Object OverallHealth -eq "WARN").Count
$critCount    = ($report | Where-Object OverallHealth -eq "CRIT").Count

Write-Status "OK"   "Healthy VMs  : $healthyCount"
Write-Status "WARN" "Warning VMs  : $warnCount"
Write-Status "CRIT" "Critical VMs : $critCount"

$report | Export-Csv -Path $OutputPath -NoTypeInformation -Encoding UTF8
Write-Status "INFO" "Report saved to: $OutputPath"

Write-Host "`nHealth check complete — $(Get-Date -Format 'HH:mm:ss')`n" -ForegroundColor Cyan
