# ============================================================
# Azure Monitor — Alerts & Log Analytics Workspace
# Author : Maruthi Naik
# Purpose: Deploy core monitoring infrastructure:
#          Log Analytics workspace, alert rules for CPU,
#          memory, disk, and VM availability
# ============================================================

variable "resource_group_name" { type = string }
variable "location"            { type = string; default = "East US" }
variable "vm_resource_id"      { type = string; description = "Resource ID of the VM to monitor" }
variable "alert_email"         { type = string; description = "Email for alert notifications" }

# ── Log Analytics Workspace ───────────────────────────────────
resource "azurerm_log_analytics_workspace" "law" {
  name                = "law-azure-monitoring"
  resource_group_name = var.resource_group_name
  location            = var.location
  sku                 = "PerGB2018"
  retention_in_days   = 30

  tags = {
    ManagedBy = "Terraform"
    Purpose   = "Azure Monitoring"
  }
}

# ── Action Group (Email Alert) ────────────────────────────────
resource "azurerm_monitor_action_group" "email_ag" {
  name                = "ag-azure-alerts-email"
  resource_group_name = var.resource_group_name
  short_name          = "AzureAlert"

  email_receiver {
    name                    = "ops-team"
    email_address           = var.alert_email
    use_common_alert_schema = true
  }
}

# ── CPU Alert (> 85% for 5 minutes) ──────────────────────────
resource "azurerm_monitor_metric_alert" "cpu_alert" {
  name                = "alert-high-cpu"
  resource_group_name = var.resource_group_name
  scopes              = [var.vm_resource_id]
  description         = "Alert when CPU utilisation exceeds 85% for 5 minutes"
  severity            = 2
  frequency           = "PT5M"
  window_size         = "PT5M"
  enabled             = true

  criteria {
    metric_namespace = "Microsoft.Compute/virtualMachines"
    metric_name      = "Percentage CPU"
    aggregation      = "Average"
    operator         = "GreaterThan"
    threshold        = 85
  }

  action {
    action_group_id = azurerm_monitor_action_group.email_ag.id
  }
}

# ── Memory Alert (< 500 MB available) ────────────────────────
resource "azurerm_monitor_metric_alert" "memory_alert" {
  name                = "alert-low-memory"
  resource_group_name = var.resource_group_name
  scopes              = [var.vm_resource_id]
  description         = "Alert when available memory drops below 500 MB"
  severity            = 2
  frequency           = "PT5M"
  window_size         = "PT15M"
  enabled             = true

  criteria {
    metric_namespace = "Microsoft.Compute/virtualMachines"
    metric_name      = "Available Memory Bytes"
    aggregation      = "Average"
    operator         = "LessThan"
    threshold        = 524288000 # 500 MB in bytes
  }

  action {
    action_group_id = azurerm_monitor_action_group.email_ag.id
  }
}

# ── VM Availability Alert ──────────────────────────────────────
resource "azurerm_monitor_metric_alert" "vm_availability" {
  name                = "alert-vm-unavailable"
  resource_group_name = var.resource_group_name
  scopes              = [var.vm_resource_id]
  description         = "Alert when VM availability drops below 1 (VM is down)"
  severity            = 0   # Critical
  frequency           = "PT1M"
  window_size         = "PT5M"
  enabled             = true

  criteria {
    metric_namespace = "Microsoft.Compute/virtualMachines"
    metric_name      = "VmAvailabilityMetric"
    aggregation      = "Average"
    operator         = "LessThan"
    threshold        = 1
  }

  action {
    action_group_id = azurerm_monitor_action_group.email_ag.id
  }
}

# ── Disk Read Latency Alert (> 100ms) ─────────────────────────
resource "azurerm_monitor_metric_alert" "disk_latency" {
  name                = "alert-high-disk-latency"
  resource_group_name = var.resource_group_name
  scopes              = [var.vm_resource_id]
  description         = "Alert when OS disk read latency exceeds 100ms"
  severity            = 3
  frequency           = "PT5M"
  window_size         = "PT15M"
  enabled             = true

  criteria {
    metric_namespace = "Microsoft.Compute/virtualMachines"
    metric_name      = "OS Disk Read Operations/Sec"
    aggregation      = "Average"
    operator         = "GreaterThan"
    threshold        = 100
  }

  action {
    action_group_id = azurerm_monitor_action_group.email_ag.id
  }
}

# ── Outputs ───────────────────────────────────────────────────
output "log_analytics_workspace_id" {
  value = azurerm_log_analytics_workspace.law.workspace_id
}

output "action_group_id" {
  value = azurerm_monitor_action_group.email_ag.id
}
