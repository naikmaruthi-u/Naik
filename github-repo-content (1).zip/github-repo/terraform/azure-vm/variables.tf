# ============================================================
# Variables — Azure Windows VM Deployment
# ============================================================

variable "resource_group_name" {
  description = "Name of the Azure Resource Group"
  type        = string
  default     = "rg-azure-vm-prod"
}

variable "location" {
  description = "Azure region for all resources"
  type        = string
  default     = "East US"
}

variable "vm_name" {
  description = "Name of the Windows Virtual Machine"
  type        = string
  default     = "vm-windows-prod"
}

variable "vm_size" {
  description = "Azure VM SKU size"
  type        = string
  default     = "Standard_D2s_v3"
}

variable "windows_sku" {
  description = "Windows Server SKU (OS version)"
  type        = string
  default     = "2022-Datacenter"
  # Options: 2016-Datacenter | 2019-Datacenter | 2022-Datacenter
}

variable "admin_username" {
  description = "Local admin username for the VM"
  type        = string
  default     = "azureadmin"
  sensitive   = true
}

variable "admin_password" {
  description = "Local admin password for the VM"
  type        = string
  sensitive   = true
}

variable "os_disk_type" {
  description = "Managed disk type for OS disk"
  type        = string
  default     = "Premium_LRS"
  # Options: Standard_LRS | StandardSSD_LRS | Premium_LRS
}

variable "os_disk_size_gb" {
  description = "OS disk size in GB"
  type        = number
  default     = 128
}

variable "vnet_address_space" {
  description = "CIDR block for the Virtual Network"
  type        = string
  default     = "10.0.0.0/16"
}

variable "subnet_prefix" {
  description = "CIDR block for the subnet"
  type        = string
  default     = "10.0.1.0/24"
}

variable "admin_source_ip" {
  description = "Source IP allowed for RDP (admin access only). Use your VPN or Bastion IP."
  type        = string
  default     = "10.0.0.0/8"
}

variable "create_public_ip" {
  description = "Whether to assign a public IP to the VM (set false in production)"
  type        = bool
  default     = false
}

variable "enable_auto_shutdown" {
  description = "Enable auto-shutdown schedule (recommended for dev/test VMs)"
  type        = bool
  default     = true
}

variable "auto_shutdown_time" {
  description = "Daily auto-shutdown time in HHMM format (IST)"
  type        = string
  default     = "2000"
}

variable "tags" {
  description = "Tags to apply to all resources"
  type        = map(string)
  default = {
    Environment = "Production"
    ManagedBy   = "Terraform"
    Owner       = "Maruthi Naik"
    Project     = "Azure-VM-Deployment"
  }
}
